return assert(dofile("data/gl_specloaderfunc.lua"))
